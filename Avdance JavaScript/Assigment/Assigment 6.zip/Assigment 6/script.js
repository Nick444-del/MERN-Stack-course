let dataLoader = () => {
    let x = new XMLHttpRequest();
    x.onload = function(){
        if(this.status == 200 && this.readyState == 4){
            let a = JSON.parse(this.responseText);
            let maintab = document.querySelector('#tab1');
            a.forEach((e) => {
                let tr = document.createElement('tr');
                maintab.appendChild(tr);
                for(let i in e){
                    if(i == 'id'){
                        let td = document.createElement('td');
                        tr.appendChild(td);
                        td.innerHTML = e[i];
                    }else if(i == 'title'){
                        let td = document.createElement('td');
                        tr.appendChild(td);
                        td.innerHTML = e[i];
                        td.className = 'tit';
                    }else if(i == 'price'){
                        let td = document.createElement('td');
                        td.innerHTML = e[i];
                        tr.appendChild(td);
                    }else if(i == 'description'){
                        let td = document.createElement('td');
                        td.innerHTML = e[i];
                        tr.appendChild(td);
                        td.className = 'des';
                    }else if(i == 'category'){
                        let td = document.createElement('td');
                        tr.appendChild(td);
                        td.className = 'cat';
                        td.innerHTML = e[i];
                    }else if(i == 'image'){
                        let td = document.createElement('img');
                        td.src = e[i];
                        td.className = 'img';
                        tr.appendChild(td);
                    }else if(i == 'rating'){
                        if(e[i].count > 0){
                            let td = document.createElement('td');
                            tr.appendChild(td);
                            td.innerHTML = e[i].count;
                        }
                        if(e[i].rate > 0){
                            let td = document.createElement('td');
                            tr.appendChild(td);
                            td.innerHTML = e[i].rate;
                        }
                    }
                }
            });
        }else{
            document.write("URL not working");
        }
    }
    x.open('GET', 'https://fakestoreapi.com/products', true);
    x.send();
};
dataLoader();