var firstName = 'Nikhil'
var lastName = 'Gorule'
var age = 23
var bachelors = 'B.C.A'
var masters = 'M.S.c IT'
var byear = 2021
var myear = 2023
var int1 = 'Reading'
var in2 = 'Travelling'

document.write('Hello I am <b>' + firstName + ' '+ lastName + '</b>. my age is <span>'+ age + '</span>. I have completd my bachelors in <b>' + bachelors + '</b>. I have completed my masters in <b>' + masters + '</b> . I completed my bachlors in <span>' + byear + '</span> and my masters in <span>' + myear + '</span>. My hobbies and interests are <i>' + int1 + '</i> and <i>' + in2 + '</i>.' )