var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30];
var i = 0;

while (i <= a.length) {
    if(a[i] % 2 == 0){
        document.write(a[i] + "<br>");
    }
    i++;
}

// var a = Array()
// var j = 0;
// var i = 0;

// while(i<=50){
//     if(i % 2 == 0){
//         a[i] = i;
//         j++;
//     }
//     i++;
// }

// document.write(a[i] + "<br>");