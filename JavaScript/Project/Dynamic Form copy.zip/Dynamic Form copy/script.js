function add() {
    let select = document.querySelector('#select_1');
    let selectValue = select.value;
    let label = document.querySelector('#Label');


    if (selectValue == '') {
        alert('Please Select the Type');
    } else {
        addFieldCode(selectValue);
    }
    selectValue.value = '';
}

function addFieldCode(y) {
    let box2 = document.querySelector('#box2');
    let code;

    if (y == 'submit') {
        code = `<div class="field_1">
                    <button class="btn" id="btn_2" onclick="submit()">submit</button>
                </div>`
    } else if (y == 'text' || y == 'email' || y == 'number') {
        code = `<div class="field_1">
                        <div class="nameing">
                            <input type="text" name="name" id="nameMe" onchange="nameIt(this)">
        </div>
                        <input type="${y}" placeholder="${y}">
                        <span onclick="remove1(this)"><i class="fa fa-times"></i></span>
                    </div>`
    } else if (y == "radio" || y == "checkbox") {
        code = `<div class="field_1">
        <div class="rNameing">
            <input type="text" name="name" id="nameMe" onchange="nameIt2(this)">
        </div>
        <div class="checkbox1">
            <button onclick="addCheckbox(this,'${y}')" class="btn btn_4 rcButton">ADD</button>
            <input type="text" placeholder="Option" class="option_1 option1">
        </div>
        <span onclick="remove1(this)"><i class="fa fa-times"></i></span>
    </div>`
    } else if (y == 'select') {
        code = `<div class="field_1">
                    <div class="sNameing">
                        <input type="text" name="name" id="nameMe" onchange="nameIt3(this)">
                    </div>
                    </div class='select1'>
                    <button onclick="addselect(this)" class="btn btn_4 rcButton">ADD</button>
                    <input type="text" placeholder="Option" class="option1">
                    <select class="select1" name="type"> </select>
                    <div class="checkbox1"> </div>
                    <span onclick="remove1(this)"><i class="fa fa-times"></i></span>
                    </div>
                </div>`
    }
    return box2.innerHTML += code;
}

function addCheckbox(y, ty) {
    let option1 = document.querySelector('.option1').value;
    let b = document.querySelector(".checkbox1");
    let code = `<div class= 'checkbox1'>
                    <label for='male'>${option1}</label>
                    <input type=${ty} id='male' name=${y}><br>
                </div>`
    b.innerHTML += code;
}

function nameIt(x) {
    x.parentNode.innerHTML = x.value+" :-"
}

function nameIt2(x){
    x.parentNode.innerHTML = x.value+" :-"
}

function nameIt3(x){
    x.parentNode.innerHTML = x.value+" :-"
}

function addselect(x) {
    let parent = x.parentElement;
    let opt = parent.querySelector('.option1');
    let a = opt.value.trim();
    let sel = parent.querySelector('.select1');
    opt.value = '';
    if (a == '') {
        alert('Please Enter the Option');
    } else {
        let optVal = document.createElement('option');
        optVal.value = a;
        optVal.text = a;
        sel.appendChild(optVal);
        console.log(a.val = '');
    }
}

function remove1(x) {
    let box2 = document.querySelector('#box2');
    box2.removeChild(x.parentElement);
}

function submit1() {
    let part1 = document.querySelector('#part1');
    let part2 = document.querySelector('#part2');
    part1.style.transform = 'scale(0)';
    setTimeout(() => {
        part1.style.display = 'none';
        part2.style.display = 'flex';
    }, 1000);
    setTimeout(() => {
        part2.style.opacity = '1';
    }, 1100);

    let icon = document.querySelectorAll('span');
    // icon.remove();
    for (let i = 0; i < icon.length; i++) {
        console.log(icon[i]);
        icon[i].remove();
    }
    // Remove Add Button
    let rcButton = document.querySelectorAll('button.btn_4');
    for (let i = 0; i < rcButton.length; i++) {
        console.log(rcButton[i]);
        rcButton[i].remove();
    }
    // Remove input field
    let rcinput = document.querySelectorAll('input.option1');
    for (let i = 0; i < rcinput.length; i++) {
        console.log(rcinput[i]);
        rcinput[i].remove();
    }

    let input = document.querySelector('input');
    input.style.width = '300px'

    let button = document.createElement('button');
    button.innerHTML = 'Submit Form';
    part2.appendChild(button);
    button.setAttribute('onclick', 'submit2()');
}

function submit2() {
    let part2 = document.querySelector('#part2');
    part2.style.transform = 'scale(0)';
    setTimeout(() => {
        part2.style.display = 'none';
    }, 1000);
    console.log(part2.innerHTML);
}